#!/usr/bin/env python3
"""Independently recompute every metric after parallel OOD evaluations finish."""
import json,datetime,hashlib,csv
from pathlib import Path
import numpy as np,sklearn
from sklearn.metrics import roc_auc_score,precision_recall_curve,roc_curve,auc
from r2_parallel_common import PAR,STUDY,sha,read,write,now
def main():
 gate=read(STUDY/'ALL_40_ID_FROZEN_GATE.json');assert len(gate['records'])==40
 names=['energy','neg_msp','neg_maxlogit','entropy','aux_uncert','centered_energy'];domains=['ssb_hard','ninco','inaturalist','texture','openimage_o'];checks=[];inputs=[];mx=0.
 for record in gate['records']:
  p=STUDY/'OOD_evaluations'/(record['label']+'_seed'+str(record['seed']));d=read(p/'metrics.json');done=read(p/'COMPLETE.json')
  assert sha(p/'metrics.json')==done['metrics_sha256'];assert sha(p/'score_arrays.npz')==done['raw_sha256'];assert d['checkpoint_sha256']==record['checkpoint_sha256'];assert d['all_40_gate_sha256']==sha(STUDY/'ALL_40_ID_FROZEN_GATE.json')
  inputs.append({'run':p.name,'metrics_sha256':sha(p/'metrics.json'),'raw_sha256':sha(p/'score_arrays.npz')})
  with np.load(p/'score_arrays.npz') as raw:
   for score in names:
    a=raw['test__'+score];assert len(a)==9000 and np.isfinite(a).all()
    for dom in domains:
     b=raw[dom+'__'+score];assert len(b)==d['sample_counts'][dom] and np.isfinite(b).all();y=np.r_[np.zeros(len(a)),np.ones(len(b))];s=np.r_[a,b].astype(np.float64);pr,re,_=precision_recall_curve(y,s);fpr,tpr,_=roc_curve(y,s,drop_intermediate=False)
     independently={'AUROC':float(roc_auc_score(y,s)),'AUPR':float(auc(re,pr)),'FPR95_complete_ties':float(fpr[np.flatnonzero(tpr>=.95)[0]])}
     for key,v in independently.items():
      diff=abs(v-d['ood_metrics'][score][dom][key]);mx=max(mx,diff);checks.append({'run':p.name,'score':score,'domain':dom,'metric':key,'abs_difference':diff,'pass':diff<=1e-12});assert diff<=1e-12,checks[-1]
 assert len(checks)==3600
 write(PAR/'ALL_3600_INDEPENDENT_METRIC_CHECKS.json',checks,True)
 write(PAR/'INDEPENDENT_RAW_METRIC_AUDIT_PASS.json',{'status':'PASS','all_pass':True,'n_models':40,'n_metric_checks':len(checks),'max_abs_difference':mx,'tolerance':1e-12,'metric_implementation':'Independent sklearn ROC and trapezoidal PR integration; complete-tie FPR95','sklearn_version':sklearn.__version__,'numpy_version':np.__version__,'source_sha256':sha(Path(__file__)),'inputs':inputs,'checks_sha256':sha(PAR/'ALL_3600_INDEPENDENT_METRIC_CHECKS.json'),'utc':now()},True)
 print('PASS_INDEPENDENT_3600_METRIC_CHECKS',mx,flush=True)
if __name__=='__main__':main()
