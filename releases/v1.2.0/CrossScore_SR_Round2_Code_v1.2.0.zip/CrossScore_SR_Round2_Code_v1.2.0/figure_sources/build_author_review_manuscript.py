from pathlib import Path
import re,json,hashlib,shutil,csv,itertools
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

B=Path(__file__).resolve().parent
OUT=B/'deliverables/CrossScore_SR_Author_Review_20261108'
SRC=OUT/'01_Manuscript';SI=OUT/'02_Supplementary';AUD=OUT/'06_Audit'
for p in [SRC,SI,AUD]:p.mkdir(parents=True,exist_ok=True)
OLD=B/'working/original_project/Overleaf_Project'
UP=B/'working/submitted_v4_20261108'
CUR=B/'deliverables/CrossScore_Revision_Working_Pack_20261105/02_Provisional_Manuscript_Source'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline=(OLD/'CrossScore_SR_Revised_Manuscript.tex').read_text();provided=(UP/'CrossScore_SR_Revised_Manuscript.tex').read_text()
normalized=provided.replace('2026J001956','2026J001958')
disclosure=re.search(r'\\section\*\{AI-assisted tools in manuscript revision\}.*?(?=\\section\*)',baseline,re.S).group()
normalized=normalized.replace('\\section*{Data Availability}',disclosure+'\\section*{Data Availability}')
normalized=normalized.replace('unfinished P2-C1 work is excluded.\n','unfinished P2-C1 work is excluded. This statement records public code availability without claiming complete replication of historical submission results.\n')
assert normalized==baseline,'Unexpected scientific difference requires manual review'
assert (UP/'supplementary_information.tex').read_bytes()==(OLD/'supplementary_information.tex').read_bytes()
text=(CUR/'CrossScore_Editorial_Revision_PROVISIONAL.tex').read_text();original_tables=re.findall(r'\\begin\{tabular\}.*?\\end\{tabular\}',text,re.S)
text=text.replace('2026J001958','2026J001956')
abstract=r'''Probability-derived teacher targets need not preserve the rankings used by an energy-based out-of-distribution (OOD) detector. We investigate this mismatch using controlled confidence alignment, scalar entropy matching and pairwise auxiliary ranking. An ImageNet-200 factorial fixes teacher temperature at 6 and student probability temperature at 1 across eight component combinations and five seeds, combining 12 archived models with 28 new 60-epoch trainings. Mean five-domain Energy AUROC is 0.86938 for cross-entropy, 0.63558 for entropy matching alone and 0.61129 for the full objective. Entropy matching has the largest adverse main effect, whereas ranking's average increment changes from +0.01204 without entropy matching to -0.00863 with it. ID classification remains similar despite substantial OOD deterioration. Logit-centering and a separate gradient-norm-matched intervention do not remove the observed failure under their specified controls. Distinct controlled CIFAR experiments also show implementation-dependent transfer; historical observations are reported separately. These findings provide component-level attribution and test two limited explanations, rather than establish a unique optimization mechanism or general ranking benefit. The analysis uses previously examined OOD domains and five-seed exact tests whose minimum two-sided p value is 0.0625.'''
assert len(abstract.split())<=200
text=re.sub(r'(\\begin\{abstract\}).*?(\\end\{abstract\})',lambda m:m[1]+'\n'+abstract+'\n'+m[2],text,flags=re.S)
intro=r'''\section{Introduction}
\label{sec:introduction}
Out-of-distribution (OOD) detection requires a score that separates inputs outside a classifier's training distribution from in-distribution (ID) inputs. Maximum softmax probability (MSP) and classifier Energy are established scoring rules with different dependence on logits~\cite{hendrycks2017baseline,liu2020energy}. A distillation objective can constrain teacher-derived confidence or uncertainty while evaluation uses a different student score. Good classification accuracy or accurate fitting of an auxiliary target does not by itself establish that the evaluation score ranks unseen OOD inputs usefully.

The practical question is therefore which training constraints support or impair the downstream score. Confidence matching, entropy matching and ranking losses are established ingredients of uncertainty-aware distillation; their combination is not the methodological novelty claimed here. Related work includes uncertainty-weighted logit distillation~\cite{kim2024leveraging}, Bayesian uncertainty quantification for distilled models~\cite{fang2024bayesian}, and residual feature-driven OOD distillation~\cite{chen2026rfkd}. Our study examines a narrower transfer question: whether teacher MSP-derived supervision and scalar entropy constraints produce reliable classifier-Energy detection, and which components are associated with negative transfer when they do not.

The distinction matters because probability constraints and Energy need not determine the same ordering. Softmax is invariant to a common shift of a sample's logits, whereas Energy changes under that shift~\cite{liu2020energy}. A separate ranking head also differs from the classifier used for deployment. These facts give an inferential boundary, not a prediction that failure must occur or an experimentally established explanation for a particular failure. Positive and negative transfer must be measured under explicit training definitions.

Earlier observations in this project included a historical CIFAR-100 improvement and a CIFAR-10 decline. Subsequent five-seed controlled CIFAR implementations changed the direction of the CIFAR-100 comparison, and the five-seed ImageNet-200 full objective reduced Energy AUROC despite preserved ID classification. We retain these outcomes and separate nonidentical protocols. We do not replace an adverse result with a better-performing configuration chosen after OOD evaluation.

We address three questions. First, under fixed teacher and student probability temperatures, which of confidence alignment (C), scalar entropy matching (E) and auxiliary ranking (R) contributes most to the observed negative transfer? Second, does ranking have a consistent effect across the other component settings? Third, do logit translation or a specified class-logit gradient-magnitude intervention account for the observed failure? The main new evidence is an eight-cell, five-seed ImageNet-200 factorial with all 40 models frozen using ID validation before this factorial's OOD inference. Its 12 archived anchors and 28 newly trained models are explicitly distinguished.

The contributions are empirical and bounded:
\begin{itemize}
\item We provide matched-temperature component estimates that associate the largest adverse Energy AUROC effect with entropy matching in the studied implementation, rather than attributing the full-objective result to ranking alone.
\item We quantify an entropy-by-ranking interaction: ranking's average increment changes sign when entropy matching is enabled. A rank-only positive difference is retained without claiming confirmed or general superiority.
\item We separate ID classification, auxiliary-head discrimination and classifier-Energy detection, and test the limited sufficiency of logit centering and combined confidence/entropy gradient-norm matching as explanations or repairs.
\item We preserve adverse results and protocol boundaries across CIFAR and ImageNet-200 and supply auditable seed-level/domain-level evidence and independent numerical checks. Previously examined OOD domains, five-seed inference and nonrandomized historical/new execution blocks limit the conclusions.
\end{itemize}

'''
start=text.index('\\section{Introduction}');end=text.index('\\section{Related Work}')
text=text[:start]+intro+text[end:]
related=r'''\section{Related Work}
\label{sec:related_work}
\subsection{OOD scores and logit geometry}
MSP uses the largest normalized class probability, while ODIN modifies confidence scoring through temperature scaling and input perturbations~\cite{hendrycks2017baseline,liang2017enhancing}. Energy uses the log-sum-exp of classifier logits and can be applied to an existing model or explicitly shaped during training~\cite{liu2020energy}. Feature-based and post-hoc alternatives include Mahalanobis scoring, nearest neighbors, activation clipping and virtual-logit matching~\cite{lee2018simple,sun2022knn,sun2021react,wang2022vim}. These approaches motivate separating the classifier, the training intervention and the inference score. We evaluate an existing Energy rule; we do not propose a new OOD score or claim that Energy is universally superior to other scores.

\subsection{Knowledge distillation and uncertainty targets}
Knowledge distillation transfers teacher outputs or representations to a student~\cite{hinton2015distilling,romero2015fitnets,zagoruyko2017paying}. Relational and contrastive formulations constrain relationships beyond individual class probabilities~\cite{park2019relational,tian2020contrastive}. Calibration transfer, uncertainty-weighted logit distillation and Bayesian formulations address distinct aspects of student uncertainty~\cite{wang2024calibration,kim2024leveraging,fang2024bayesian}. Their objectives do not supply a universal guarantee about the ranking of an independently chosen OOD score. Conversely, the present negative findings do not invalidate these methods or constitute an authenticated performance comparison with their original software.

\subsection{Boundary relative to related OOD distillation}
Residual feature-driven knowledge distillation (RFKD) combines confidence-aware supervision, relational/ordering constraints and Energy-based inference~\cite{chen2026rfkd}. The shared ingredients are established and are not claimed as individually novel here. Our question and evidence concern component attribution for an MSP-targeted controlled implementation, including negative transfer, temperature sensitivity and disagreement between an auxiliary head and classifier Energy. The limited matched teacher-ordering-target contrast isolates a target choice within our protocol; it is not a ranking of independent publications. Historical observations with incompletely authenticated execution provenance are labeled separately and do not establish new algorithmic priority. The new controlled factorial and its declared replication limits provide the central evidence.

'''
start=text.index('\\section{Related Work}');end=text.index('\\section{Study framework and controlled objectives}')
background=re.search(r'\\begin\{equation\}.*?\\end\{equation\}',text[start:end],re.S).group()
related=related.replace('\\subsection{Knowledge distillation and uncertainty targets}',background+'\nThe score orientation used in this study is specified explicitly below.\n\n\\subsection{Knowledge distillation and uncertainty targets}')
text=text[:start]+related+text[end:]
# Make probability and Energy temperature conventions explicit without changing losses.
text=text.replace(r'z_T^{(c)}(\mathbf{x})\right)',r'z_T^{(c)}(\mathbf{x})/T_t\right)').replace(r'z_T^{(j)}(\mathbf{x})\right)',r'z_T^{(j)}(\mathbf{x})/T_t\right)')
old='In the original method equations, temperature scaling is implicit in the teacher probabilities; for the corrected experimental variant the teacher probability is obtained by replacing each teacher logit $z_T^{(c)}$ above by $z_T^{(c)}/T$, with $T=6$. The archived legacy implementation uses $T=1$ in these probability-derived losses.'
new='Here $T_t$ denotes the teacher probability temperature. It is 6 in the corrected-teacher implementation and the complete component factorial, and 1 in the archived legacy as-code comparison. Student probabilities below use $T_s=1$ in the primary factorial; the separately labeled temperature-sensitivity follow-up also examines $T_s=6$. The inference Energy temperature is fixed at 1. These are different conventions and are not interchanged.'
assert old in text;text=text.replace(old,new)
text=text.replace('the negative energy score is defined as','the OOD-positive Energy score is defined as').replace('logits-derived negative energy','classifier Energy').replace('logits-derived negative-energy','classifier-Energy').replace('negative-energy OOD score','OOD-positive Energy score').replace('The score is negative Energy,','The score is Energy,').replace('negative energy and','Energy and')
text=text.replace('Importantly, the auxiliary branch introduced during training is discarded after optimisation. Consequently, inference depends only on classification logits generated by the student network and introduces no additional computational overhead.','The auxiliary branch is removed after training. Inference uses the student classifier logits alone, so the evaluated architecture has no extra uncertainty head. This architectural statement is distinct from training cost and OOD accuracy.')
# Bring the mathematical boundary into the study definitions, not a novelty claim.
start=text.index('\\subsection{Theoretical non-identifiability of energy ranking}');end=text.index('\\section{Discussion}',start)
boundary=text[start:end].replace('\\subsection{Theoretical non-identifiability of energy ranking}','\\subsection{Score geometry and an inferential boundary}')
boundary=boundary.replace('Let $z(x)', 'The softmax/Energy relationship is established background~\\cite{liu2020energy}. Let $z(x)')
text=text[:start]+text[end:];where=text.index('\\section{Experiments}');text=text[:where]+boundary+'\n'+text[where:]
# Primary controlled ImageNet results now precede the distinct CIFAR cohort.
start=text.index('\\subsection{Matched-backbone evaluation');end=text.index('\\subsection{Direct same-objective ImageNet-200 evaluation}',start);cifar=text[start:end]
text=text[:start]+text[end:];where=text.index('\\subsection{Historical observations and checkpoint comparisons}');text=text[:where]+cifar+'\n'+text[where:]
protocol=r'''\paragraph{Primary ImageNet-200 cohort.}
The component study uses 258,951 ID training images, 1,000 ID validation images and 9,000 ID test images from fixed ImageNet-200 benchmark lists. The frozen teacher is an ImageNet-1K-pretrained ResNet-50 restricted to the 200 class indices and is not fine-tuned for this study. The student is a randomly initialized, ImageNet-stem ResNet-18 with 200 outputs and a 512--128--1 ReLU auxiliary head. Training uses 60 epochs, batch size 512, SGD with momentum 0.9 without Nesterov, learning rate 0.1, weight decay $5\times10^{-4}$ and per-optimizer-step cosine decay to $10^{-6}$. Both networks receive the same RandomResizedCrop(224)/horizontal-flip/ImageNet-normalized training batch. Evaluation uses resize 256 and center crop 224. AMP uses an initial gradient-scaler value of 1,024; skipped optimizer steps remain recorded and are not exclusion criteria.

Each of the eight C/E/R cells has seeds 42--46 with unit enabled coefficients. A checkpoint is selected only by ID validation accuracy, allowing epoch 0 and retaining the earlier epoch on ties. Twelve protocol-matched historical models are reused and 28 missing runs are newly trained. Initial-state fingerprints agree among the new runs of each seed; historical initial-state fingerprints were not archived, so reuse is not claimed as bitwise replay. The hardware scheduling blocks are not randomized. Only ID training images are used for student optimization. The pretrained teacher is not assumed to be semantically naive to every OOD class, particularly the ImageNet classes held out from the 200-class student task.

The five OOD domains and sample counts are SSB-hard (49,000), NINCO (5,879), iNaturalist (10,000), Textures (5,160) and OpenImage-O (15,869), following the archived OpenOOD lists~\cite{guo2024openood}. All 40 ID models are frozen before any OOD inference in this factorial. These OOD domains were examined in earlier stages of the project and are not untouched validation shifts. Within each seed, domains are weighted equally. All reported FPR95 values use the first complete-tie ROC threshold reaching at least 95\% OOD true-positive rate; AUPR is trapezoidal OOD-positive PR area, rather than average precision. Exact two-sided sign-flip tests enumerate all 32 seed-sign assignments. Paired $t$ intervals are descriptive, depend on small-sample assumptions and are not multiplicity-adjusted confirmation.

\paragraph{Distinct CIFAR cohorts.}
'''
needle='\\subsubsection{Datasets}';assert needle in text;text=text.replace(needle,protocol+'\n'+needle,1)
text=text.replace('Unless otherwise stated, CIFAR-100 is adopted as the primary ID benchmark because it has more class labels than CIFAR-10, while CIFAR-10 is used to examine how transfer behavior changes under a comparatively simpler setting.','CIFAR-100 and CIFAR-10 form a distinct supporting cohort; they are not pooled with the primary ImageNet-200 component study. The historical observations and newer controlled five-seed CIFAR programs are also kept separate.')
# Strengthen interpretation without claiming a unique cause.
needle='The completed matched-temperature factorial narrows this interpretation:'
at=text.index(needle);end=text.index('\n\n',at)
text=text[:end]+r''' The magnitude ordering of C and E is conditional on their original, unnormalized loss scales and unit coefficients; it is not an intrinsic ranking of component quality under all weightings. The high entropy of E-enabled students is consistent with fitting softened teacher targets while retaining class argmax, but we have not isolated complete gradient directions or optimization trajectories. The reported gradient-norm and centering interventions therefore test limited explanations rather than prove a unique mechanism.'''+text[end:]
text=text.replace('Empirically, the observed changes in feature scatter, logit geometry and training-gradient conflict remain descriptive or exploratory rather than a validated causal model.','The component factorial adds implementation-scoped loss attribution. Feature scatter, score dispersion and training-gradient conflict remain descriptive or exploratory rather than a complete causal model.')
# Factual tool-use transparency reflects the current journal policy and revision work.
text=re.sub(r'\\section\*\{AI-assisted tools in manuscript revision\}.*?(?=\\section\*)',r'''\section*{Use of AI-assisted tools}
ChatGPT (OpenAI) was used to assist code preparation, organization of the experimental evidence and manuscript drafting during this revision. Numerical outputs were checked against archived model records and separately implemented metric and statistical calculations. The authors retain responsibility for verification, scientific interpretation and approval of the final text. No AI system is listed as an author.

'''.replace('\\','\\\\'),text,flags=re.S)
text=text.replace('The B2 controlled benchmark excludes OOD images from student training.','The B2 controlled benchmark and the ImageNet-200 component factorial exclude OOD evaluation images from student optimization. ImageNet-200 and its five OOD domains follow the public OpenOOD benchmark lists (\\url{https://github.com/Jingkang50/OpenOOD}); their original dataset access conditions continue to apply. The ImageNet-1K-pretrained teacher is not assumed to have unseen OOD semantic classes.')
text=text.replace('Their exact fixed-version DOI must be added before this revision is submitted.','The exact fixed-version DOI for the accompanying round-two software archive must be inserted after deposition and before journal submission. The author-review package records this outstanding identifier explicitly; no earlier DOI is assigned to unarchived additions.')
# The raw original numeric tables remain exact; all newly quoted numbers come from audited JSON.
assert all(t in text for t in original_tables),'Existing numeric table changed unexpectedly'
assert text.count('\\begin{equation}')==23
assert '2026J001956' in text and '2026J001958' not in text
assert '\\section{Methodology}' not in text and 'virtually all existing' not in text.lower()
# Retain only references actually cited after the focused rewrite.
used=set()
for group in re.findall(r'\\cite\w*\{([^}]+)\}',text):used.update(x.strip() for x in group.split(','))
bibstart=text.index('\\begin{thebibliography}');head=text[:bibstart];bib=text[bibstart:]
items=list(re.finditer(r'\\bibitem\{([^}]+)\}',bib));removed=[]
for i in range(len(items)-1,-1,-1):
 key=items[i][1];a=items[i].start();z=items[i+1].start() if i+1<len(items) else bib.index('\\end{thebibliography}')
 if key not in used:removed.append(key);bib=bib[:a]+bib[z:]
text=head+bib
assert used<=set(re.findall(r'\\bibitem\{([^}]+)\}',text))
(SRC/'Manuscript_Revised.tex').write_text(text)
shutil.copy2(UP/'elsarticle.cls',SRC/'elsarticle.cls');shutil.copy2(UP/'framework_architecture.pdf',SRC/'framework_architecture.pdf')
supp=(CUR/'supplementary_information.tex').read_text();supp=supp.replace('On the Limits of MSP-to-Energy Uncertainty Transfer: A Controlled Study of Ranking Supervision for OOD Detection','Limits of maximum softmax probability supervision for energy-based out-of-distribution detection')
(SI/'Supplementary_Information_Revised.tex').write_text(supp)

# Black-and-white seed-level figure; no fitted trend or confidence claim.
R=json.loads((B/'evidence/factorial_complete_20261108/FACTORIAL_SCIENTIFIC_RESULT.json').read_text());V=json.loads((B/'evidence/factorial_complete_20261108/INDEPENDENT_FACTORIAL_STATISTICS_AUDIT.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'ps.fonttype':42})
fig,axs=plt.subplots(1,2,figsize=(10.5,3.7),gridspec_kw={'width_ratios':[1.7,1]})
bits=list(itertools.product([0,1],repeat=3));labs=['CE','R','E','E+R','C','C+R','C+E','C+E+R'];source=[]
for i,(b,lab) in enumerate(zip(bits,labs)):
 x=R['cell_summaries'][f'energy/AUROC/{b}'];ys=np.array(x['seed_values']);axs[0].scatter(i+np.linspace(-.12,.12,5),ys,s=19,facecolors='white',edgecolors='black',linewidth=.8,zorder=3)
 axs[0].errorbar(i,x['mean'],yerr=x['sample_sd'],fmt='s',color='black',markersize=4,capsize=3,linewidth=1.1,zorder=4)
 for seed,value in zip(range(42,47),ys):source.append({'panel':'A','configuration':lab,'seed':seed,'Energy_AUROC':float(value)})
axs[0].set_xticks(range(8),labs,rotation=30);axs[0].set_ylabel('Energy AUROC');axs[0].set_ylim(.575,.91);axs[0].set_title('A  Component combinations',loc='left',fontweight='bold')
lo=V['paired_energy_contrasts']['R_effect_E0_average_C']['AUROC'];hi=V['paired_energy_contrasts']['R_effect_E1_average_C']['AUROC']
for i,seed in enumerate(range(42,47)):
 y=[lo['seed_values'][i],hi['seed_values'][i]];axs[1].plot([0,1],y,color='.6',linewidth=.8,marker='o',markersize=4,markerfacecolor='white',markeredgecolor='black')
 for setting,value in zip(['E off','E on'],y):source.append({'panel':'B','configuration':setting,'seed':seed,'Energy_AUROC':float(value)})
axs[1].plot([0,1],[lo['mean'],hi['mean']],color='black',linewidth=2,marker='s',markersize=5);axs[1].axhline(0,color='black',linestyle='--',linewidth=.8);axs[1].set_xticks([0,1],['E off','E on']);axs[1].set_xlim(-.25,1.25);axs[1].set_ylabel('Increment from adding R');axs[1].set_title('B  Ranking depends on entropy',loc='left',fontweight='bold')
for ax in axs:ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',color='.9',linewidth=.6)
fig.tight_layout(pad=1.5);fig.savefig(SRC/'factorial_seed_results.pdf');fig.savefig(SRC/'factorial_seed_results.png',dpi=300);plt.close(fig)
with (SRC/'factorial_figure_source.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=['panel','configuration','seed','Energy_AUROC']);w.writeheader();w.writerows(source)
plot=r'''\begin{figure}[htbp]
\centering
\includegraphics[width=\textwidth]{factorial_seed_results.pdf}
\caption{Seed-level component results and conditional ranking effects. Panel A shows five-domain Energy AUROC for each component combination; open circles are individual seeds and black squares indicate means with sample-SD error bars. Panel B shows each seed's increment from adding R, averaged over C, with E disabled or enabled; the black line connects the corresponding means. The lines do not represent a fitted model. The five seeds are paired units, and the OOD domains were examined previously. This figure makes no multiplicity-adjusted significance claim.}
\label{fig:factorial_seed_results}
\end{figure}
'''
text=(SRC/'Manuscript_Revised.tex').read_text();needle='Entropy matching had the largest adverse mean Energy AUROC main effect,';at=text.index(needle);text=text[:at]+plot+'\n'+text[at:];(SRC/'Manuscript_Revised.tex').write_text(text)
recon={'provided_zip_sha256':sha(B/'upload/Overleaf_SR.zip'),'provided_main_source_sha256':sha(UP/'CrossScore_SR_Revised_Manuscript.tex'),'provided_supp_source_identical_to_prior':True,'provided_source_scientific_difference_from_prior':'none; differences are corrected grant1956, omitted tool-use paragraph and one code-availability closing sentence','provided_main_pdf_actual_content':'Supplementary Information, nine pages; not a main-article PDF','provided_main_pdf_sha256':sha(B/'upload/Overleaf_SR.pdf'),'source_baseline_reconciled':True,'main_pdf_byte_reconciliation_possible':False,'latest_grant_preserved':'2026J001956','authors_order_preserved':True,'old_numeric_table_blocks_preserved':len(original_tables),'numbered_equations':23,'abstract_word_count':len(abstract.split()),'removed_uncited_reference_keys':removed,'new_figure':'Audited seed-level results; black and white; source CSV included','DOI_for_new_code':'pending actual repository deposition','not_for_journal_submission_until_DOI_and_author_approval':True}
(AUD/'SOURCE_RECONCILIATION.json').write_text(json.dumps(recon,indent=2)+'\n')
print(json.dumps({'output':str(OUT),'abstract_words':len(abstract.split()),'numeric_tables_preserved':len(original_tables),'removed_uncited_refs':len(removed),'new_source_sha256':sha(SRC/'Manuscript_Revised.tex')}))
