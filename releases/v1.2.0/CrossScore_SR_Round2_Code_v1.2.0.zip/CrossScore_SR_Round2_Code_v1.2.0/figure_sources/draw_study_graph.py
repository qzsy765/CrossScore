from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import black
from reportlab.pdfbase.pdfmetrics import stringWidth, registerFont
from reportlab.pdfbase.ttfonts import TTFont
registerFont(TTFont("StudySans", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
registerFont(TTFont("StudySans-Bold", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
P=Path(__file__).resolve().parent/'deliverables/CrossScore_SR_Author_Review_20261108/01_Manuscript'
P.mkdir(parents=True,exist_ok=True)
c=canvas.Canvas(str(P/'framework_architecture.pdf'),pagesize=(520,525))
c.setTitle('Computational interventions under study')
def label(x,y,text,size=11,bold=False):
 c.setFont('StudySans-Bold' if bold else 'StudySans',size);c.drawCentredString(x*520/720,y,text)
def box(x,y,w,h,lines,size=11):
 c.setStrokeColor(black);c.setLineWidth(.8);c.rect((x-w/2)*520/720,y-h/2,w*520/720,h,stroke=1,fill=0)
 for i,t in enumerate(lines):label(x,y+(len(lines)-1)*size*.6-i*size*1.2-3,t,size)
def arrow(points):
 points=[(x*520/720,y) for x,y in points]
 c.setLineWidth(.8);p=c.beginPath();p.moveTo(*points[0])
 for q in points[1:]:p.lineTo(*q)
 c.drawPath(p)
 a,b=points[-2:];x,y=b;dx=x-a[0];dy=y-a[1];n=max(abs(dx),abs(dy));ux,uy=dx/n,dy/n;px,py=-uy,ux
 p=c.beginPath();p.moveTo(x,y);p.lineTo(x-7*ux+2.6*px,y-7*uy+2.6*py);p.lineTo(x-7*ux-2.6*px,y-7*uy-2.6*py);p.close();c.drawPath(p,stroke=0,fill=1)
label(360,505,'A  Training interventions',13,True)
box(360,472,250,32,['ID image x and class label y'])
box(168,411,230,38,['Frozen ResNet-50 teacher'])
box(542,411,230,38,['ResNet-18 student'])
arrow([(304,456),(304,443),(168,443),(168,430)])
arrow([(416,456),(416,443),(542,443),(542,430)])
box(168,346,208,42,['Teacher probability p_T','Temperature T_t'])
box(542,346,208,42,['Shared feature f(x)','512 dimensions'])
arrow([(168,392),(168,367)]);arrow([(542,392),(542,367)])
box(150,269,240,48,['Teacher targets','confidence, entropy, MSP rank'],10.5)
box(410,269,184,48,['Training-only head h(f)','512 to 128 to 1'],10.5)
box(612,269,176,48,['Classifier logits z_S','Probabilities p_S'],10.5)
arrow([(168,325),(168,307),(150,307),(150,293)])
arrow([(542,325),(542,307),(410,307),(410,293)])
arrow([(542,325),(542,307),(612,307),(612,293)])
box(360,177,662,68,['Combined ID training objective','Cross-entropy plus enabled confidence (C), entropy (E) and ranking (R) terms','C and E constrain class probabilities; R constrains the auxiliary head'],11)
arrow([(150,245),(150,211)]);arrow([(410,245),(410,211)]);arrow([(612,245),(612,211)])
label(360,123,'Student parameters are updated; teacher parameters remain frozen',10)
label(360,93,'B  Inference',13,True)
box(78,49,108,38,['Input x'])
box(280,49,202,38,['Student classifier','teacher and head removed'],10)
box(510,49,182,38,['Classifier Energy','-logsumexp(z_S)'],10)
box(662,49,98,38,['OOD','threshold'],9.5)
arrow([(132,49),(179,49)]);arrow([(381,49),(419,49)]);arrow([(601,49),(613,49)])
c.save()
print(P/'framework_architecture.pdf')
