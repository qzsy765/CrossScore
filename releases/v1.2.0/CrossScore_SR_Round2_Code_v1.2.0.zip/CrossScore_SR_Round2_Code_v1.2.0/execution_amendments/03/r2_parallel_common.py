import os,sys,json,hashlib,time,datetime,socket,subprocess,fcntl,csv,math,errno
from pathlib import Path
PAR=Path(__file__).resolve().parent
STUDY=PAR.parent
ROOT=STUDY.parent.parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def io_retry(fn):
 # Retry transient shared-filesystem reads only. Validation failures still raise.
 for attempt in range(10):
  try:return fn()
  except OSError as exc:
   if exc.errno not in {errno.EIO,errno.ESTALE,errno.ETIMEDOUT,errno.ENOENT} or attempt==9:raise
   time.sleep(min(.1*(2**attempt),2.0))
def sha(p):
 def once():
  h=hashlib.sha256()
  with Path(p).open('rb') as f:
   for b in iter(lambda:f.read(8<<20),b''):h.update(b)
  return h.hexdigest()
 return io_retry(once)
def read(p):return io_retry(lambda:json.loads(Path(p).read_text()))
def write(p,v,exclusive=False):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 if exclusive:
  with p.open('x') as f:f.write(json.dumps(v,indent=2)+'\n')
 else:
  tmp=p.with_name(p.name+'.tmp.'+str(os.getpid()))
  def once():tmp.write_text(json.dumps(v,indent=2)+'\n');os.replace(tmp,p)
  io_retry(once)
def publish_status(p,v):
 # Progress and heartbeats are diagnostic. Frozen artifacts and claims use write().
 try:write(p,v);return True
 except OSError as exc:
  print(json.dumps({'diagnostic_status_write_warning':repr(exc),'path':str(p),'utc':now()}),flush=True);return False
def read_diagnostic_json(p,previous=None):
 try:return read(p)
 except (OSError,json.JSONDecodeError) as exc:
  warning={'diagnostic_read_warning':repr(exc),'path':str(p),'observed_utc':now()}
  print(json.dumps(warning),flush=True)
  return {**(previous or {}),'diagnostic_warning':warning}
def proc_state(pid):
 try:return Path(f'/proc/{pid}/stat').read_text().split()[2]
 except FileNotFoundError:return None
def load_plans(expected_sha):
 assert sha(PAR/'AMENDMENT.json')==expected_sha
 amend=read(PAR/'AMENDMENT.json');plan=read(STUDY/'FROZEN_FACTORIAL_PROTOCOL.json')
 assert sha(STUDY/'FROZEN_FACTORIAL_PROTOCOL.json')==amend['original_protocol_sha256']
 for n,digest in amend['parallel_source_sha256'].items():assert sha(PAR/n)==digest,n
 assert sha(PAR/'NUMPY_VENDOR_MANIFEST.json')==amend['numpy_vendor_manifest_sha256']
 for item in read(PAR/'NUMPY_VENDOR_MANIFEST.json')['files']:assert sha(PAR/'numpy1264_vendor'/item['path'])==item['sha256'],item['path']
 return amend,plan
def abort_check():
 for n in ['ABORT_AFTER_CURRENT_JOB.json','GLOBAL_ERROR.json']:
  if (PAR/n).exists():raise RuntimeError('Parallel barrier stopped: '+n)
def validate_run(r,plan,smoke=False):
 sys.path.insert(0,str(STUDY));import r2_component_factorial_controller as original
 original.PLAN=plan
 return io_retry(lambda:original.validate_new(r,smoke))
def validate_sources(plan):
 for item in plan['source_dependencies']+plan['dataset_lists']:assert sha(item['path'])==item['sha256'],item['path']
def runid(r):return r['label']+'_seed'+str(r['seed'])
class DeviceLock:
 def __init__(self,node,uuid,heartbeat):self.node=node;self.uuid=uuid;self.hb=heartbeat;self.fd=None
 def __enter__(self):
  locks=ROOT/'.gpu_device_locks';locks.mkdir(exist_ok=True);self.fd=(locks/(self.uuid+'.lock')).open('a+')
  while True:
   try:fcntl.flock(self.fd.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);break
   except BlockingIOError:self.hb('WAIT_GPU_LOCK');abort_check();time.sleep(20)
  self.owner=locks/(self.uuid+'.owner.json');publish_status(self.owner,{'state':'RUNNING','node':self.node,'gpu_uuid':self.uuid,'pid':os.getpid(),'host':socket.gethostname(),'study':str(PAR),'utc':now()});return self
 def __exit__(self,*_):
  publish_status(self.owner,{'state':'RELEASED','node':self.node,'pid':os.getpid(),'study':str(PAR),'utc':now()});fcntl.flock(self.fd.fileno(),fcntl.LOCK_UN);self.fd.close()
def idle_gpu(heartbeat):
 while True:
  s=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader'],text=True).strip()
  if not s:return
  heartbeat('WAIT_EXTERNAL_GPU_PROCESS',gpu_processes=s);abort_check();time.sleep(20)
