#!/usr/bin/env python3
"""Hardware-only amendment: unchanged scientific trainer and static disjoint jobs."""
import argparse,concurrent.futures,csv,datetime,hashlib,json,os,signal,socket,subprocess,sys,time,shutil
from pathlib import Path
from r2_parallel_common import *
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--node',choices=['A','B','C'],required=True);ap.add_argument('--amendment-sha',required=True);args=ap.parse_args()
 amend,plan=load_plans(args.amendment_sha);cfg=amend['nodes'][args.node];wd=PAR/'workers'/args.node;wd.mkdir(parents=True,exist_ok=True)
 def hb(phase,**kw):publish_status(wd/'HEARTBEAT.json',{'node':args.node,'pid':os.getpid(),'host':socket.gethostname(),'utc':now(),'phase':phase,**kw})
 write(wd/'WORKER_STARTED.json',{'node':args.node,'pid':os.getpid(),'host':socket.gethostname(),'utc':now(),'amendment_sha256':args.amendment_sha},True)
 uuid=subprocess.check_output(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],text=True).strip();assert uuid==cfg['gpu_uuid'];assert socket.gethostname()==cfg['host']
 hb('VERIFY_SOURCES_AND_RUNTIME');validate_sources(plan)
 import torch,torchvision,numpy,PIL
 runtime={'python':sys.version.split()[0],'torch':torch.__version__,'cuda':torch.version.cuda,'cudnn':torch.backends.cudnn.version(),'torchvision':torchvision.__version__,'numpy':numpy.__version__,'PIL':PIL.__version__}
 assert runtime==amend['expected_runtime'],(runtime,amend['expected_runtime'])
 write(wd/'SOURCE_AND_RUNTIME_PREFLIGHT_PASS.json',{'runtime':runtime,'gpu_uuid':uuid,'original_sources_and_lists_pass':True,'utc':now()},True)
 def child(cmd,logpath,phase):
  abort_check();idle_gpu(hb);logpath.parent.mkdir(parents=True,exist_ok=True)
  with logpath.open('x') as log:
   p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'8','OPENBLAS_NUM_THREADS':'1','CROSSSCORE_IM200_TRAINROOT':cfg['train_cache']})
   while p.poll() is None:hb(phase,child_pid=p.pid,log=str(logpath));time.sleep(10)
   if p.returncode:raise RuntimeError({'phase':phase,'exit_code':p.returncode,'log':str(logpath)})
 def claim(r,phase):
  name=phase+'_'+runid(r);v={'node':args.node,'gpu_uuid':uuid,'host':socket.gethostname(),'run':runid(r),'phase':phase,'utc':now(),'amendment_sha256':args.amendment_sha};write(PAR/'claims'/(name+'.json'),v,True)
 def command(r,smoke=False):
  c,e,k=r['components'];v=[sys.executable,'-u',str(STUDY/'r2_component_factorial_train.py'),'--mode','CrossScore_T6_Corrected','--seed',str(r['seed']),'--conf',str(c),'--entropy',str(e),'--rank',str(k),'--out',r['path']]
  if smoke:v+=['--epochs','1','--batch-size','32','--workers','2','--max-train-batches','2','--max-val-batches','1']
  return v
 def stage_cache():
  if args.node in amend.get('verified_cache_reuse',{}):
   previous=amend['verified_cache_reuse'][args.node]
   assert sha(previous['marker_path'])==previous['marker_sha256']
   marker=read(previous['marker_path'])
   assert marker['all_source_and_destination_hashes_match_primary'] and marker['n']==258951
   assert marker['csv_sha256']==amend['training_cache_manifest_sha256']
   assert sha(previous['csv_path'])==marker['csv_sha256']
   assert Path(cfg['train_cache']).is_dir()
   write(wd/'TRAIN_CACHE_COMPLETE.json',{'reused_prior_all_image_readback_gate':True,'prior_marker_path':previous['marker_path'],'prior_marker_sha256':previous['marker_sha256'],'prior_csv_path':previous['csv_path'],**marker},True)
   return
  if args.node=='A':
   old=read(STUDY/'TRAIN_CACHE_COMPLETE.json');assert old['csv_sha256']==amend['training_cache_manifest_sha256'];assert sha(STUDY/'TRAIN_CACHE_SHA256.csv')==old['csv_sha256'];assert Path(cfg['train_cache']).is_dir();write(wd/'TRAIN_CACHE_COMPLETE.json',{'reuse_verified_primary_cache':True,**old},True);return
  dest=Path(cfg['train_cache']);dest.mkdir(parents=True,exist_ok=False);source=Path(plan['persistent_train_root']);rows=[x.rsplit(' ',1)[0] for x in Path(plan['train_list']).read_text().splitlines()];assert len(rows)==258951;started=time.time();used=0
  def copy(item):
   rel=Path(*Path(item).parts[-2:]);src=source/rel;dst=dest/rel;dst.parent.mkdir(parents=True,exist_ok=True);b=src.read_bytes();digest=hashlib.sha256(b).hexdigest()
   with dst.open('xb') as f:f.write(b)
   assert sha(dst)==digest
   return str(rel),len(b),digest
  with (wd/'TRAIN_CACHE_SHA256.csv').open('x',newline='') as f,concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
   w=csv.writer(f);w.writerow(['relative_path','size_bytes','source_and_destination_sha256'])
   for start in range(0,len(rows),256):
    for rec in pool.map(copy,rows[start:start+256]):w.writerow(rec);used+=rec[1]
    cg=Path('/sys/fs/cgroup');lim=(cg/'memory.max').read_text().strip();room=int(lim)-int((cg/'memory.current').read_text()) if lim!='max' else 1<<60
    assert used<80*(1<<30) and shutil.disk_usage('/dev/shm').free>24*(1<<30) and room>32*(1<<30),'Cache resource budget exceeded'
    if start%2560==0:hb('STAGING_TRAIN_CACHE',n_copied=min(start+256,len(rows)),bytes=used)
  digest=sha(wd/'TRAIN_CACHE_SHA256.csv');assert digest==amend['training_cache_manifest_sha256'],'Full copied dataset differs from primary cache manifest'
  write(wd/'TRAIN_CACHE_COMPLETE.json',{'n':len(rows),'bytes':used,'csv_sha256':digest,'all_source_and_destination_hashes_match_primary':True,'elapsed_seconds':time.time()-started,'utc':now()},True)
 # Preserve the already-running primary model. The old parent is retired only after its child finishes naturally.
 if args.node=='A' and amend.get('adopt_existing_training',True):
  old=amend['handoff'];pid=old['active_child_pid'];parent=old['original_controller_pid']
  while proc_state(pid) not in [None,'Z','X']:
   hb('ADOPT_EXISTING_TRAINING',child_pid=pid,log=old['original_heartbeat']['log'],run=old['active_run']);time.sleep(10)
  r=next(r for r in plan['new_runs'] if runid(r)==old['active_run']);record=validate_run(r,plan)
  write(wd/'ADOPTED_MODEL_COMPLETED.json',{'record':record,'child_finished_naturally':True,'utc':now()},True)
  assert proc_state(parent)=='T';assert str(STUDY/'r2_component_factorial_controller.py') in Path(f'/proc/{parent}/cmdline').read_bytes().decode().replace('\x00',' ')
  os.kill(parent,signal.SIGTERM);os.kill(parent,signal.SIGCONT)
  for _ in range(50):
   if proc_state(parent) in [None,'Z','X']:break
   time.sleep(.1)
  assert proc_state(parent) in [None,'Z','X']
  write(PAR/'LEGACY_DISPATCHER_RETIRED.json',{'pid':parent,'reason':'Authorized static three-GPU hardware handoff after active child natural completion','completed_model':r['path'],'utc':now()},True)
 if args.node=='A' and not amend.get('adopt_existing_training',True):
  retired=amend['legacy_retired_record'];assert sha(retired['path'])==retired['sha256'];assert read(retired['path'])['pid']==2256
  write(wd/'NO_ACTIVE_HANDOFF_REQUIRED.json',{'legacy_dispatcher_already_retired':True,'all_six_completed_models_reaudited':True,'utc':now()},True)
 with DeviceLock(args.node,uuid,hb):
  stage_cache()
  if args.node in amend.get('verified_smoke_reuse',{}):
   old=amend['verified_smoke_reuse'][args.node];assert sha(old['path'])==old['sha256'];marker=read(old['path'])
   assert marker['initial_states_match_primary_seed42'] and len(marker['records'])==3
   write(wd/'THREE_SMOKES_PASS.json',{'reused_previous_unchanged_scientific_smokes':True,'previous_marker_path':old['path'],'previous_marker_sha256':old['sha256'],**marker},True)
  elif args.node!='A':
   smokes=[]
   for bits in [[1,0,0],[0,1,0],[0,0,1]]:
    label='C%dE%dR%d'%tuple(bits);r={'label':label,'seed':42,'components':bits,'path':str(wd/'smokes'/label)};child(command(r,True),wd/'logs'/('smoke_'+label+'.log'),'SMOKE_'+label);v=validate_run(r,plan,True);assert v['initial_state_sha256']==amend['primary_seed42_initial_sha256'];smokes.append(v)
   write(wd/'THREE_SMOKES_PASS.json',{'records':smokes,'not_formal_results':True,'initial_states_match_primary_seed42':True,'utc':now()},True)
  else:assert (STUDY/'THREE_SINGLE_COMPONENT_SMOKES_PASS.json').exists()
  records=[]
  for r in cfg['training_jobs']:
   abort_check();validate_sources(plan);assert not Path(r['path']).exists(),r['path'];claim(r,'TRAIN')
   child(command(r),STUDY/'logs'/(runid(r)+'.log'),'TRAIN_'+runid(r));records.append(validate_run(r,plan));publish_status(wd/'TRAINING_PROGRESS.json',{'n_complete':len(records),'n_assigned':len(cfg['training_jobs']),'records':records,'utc':now()})
  write(wd/'ASSIGNED_TRAINING_COMPLETE.json',{'n':len(records),'records':records,'utc':now()},True)
 while not (STUDY/'ALL_40_ID_FROZEN_GATE.json').exists():hb('WAIT_ALL_40_ID_FREEZE');abort_check();time.sleep(20)
 with DeviceLock(args.node,uuid,hb):
  for r in cfg['evaluation_jobs']:
   abort_check();out=STUDY/'OOD_evaluations'/runid(r);assert not out.exists();claim(r,'OOD')
   child([sys.executable,'-u',str(STUDY/'r2_component_factorial_evaluate.py'),'--label',r['label'],'--seed',str(r['seed'])],STUDY/'logs'/('eval_'+runid(r)+'.log'),'OOD_'+runid(r));assert (out/'COMPLETE.json').exists()
  write(wd/'ASSIGNED_OOD_COMPLETE.json',{'n':len(cfg['evaluation_jobs']),'utc':now()},True)
 hb('WORKER_COMPLETE')
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  node=sys.argv[sys.argv.index('--node')+1] if '--node' in sys.argv else 'UNKNOWN';write(PAR/'workers'/node/'ERROR.json',{'error':repr(exc),'utc':now(),'partial_outputs_preserved':True});raise
