#!/usr/bin/env python3
"""CPU coordinator; freeze all 40 ID models before any component-factorial OOD."""
import argparse,os,sys,time,json,csv,statistics,subprocess,socket
from pathlib import Path
from r2_parallel_common import *
def main():
 p=argparse.ArgumentParser();p.add_argument('--amendment-sha',required=True);args=p.parse_args();amend,plan=load_plans(args.amendment_sha)
 write(PAR/'FINALIZER_STARTED.json',{'pid':os.getpid(),'host':socket.gethostname(),'utc':now(),'amendment_sha256':args.amendment_sha},True)
 verified={r['path']:r for r in amend['already_completed_records']};snapshots={}
 while True:
  for node in ['A','B','C']:
   error=PAR/'workers'/node/'ERROR.json'
   if error.exists():raise RuntimeError({'node':node,'worker_error':read(error)})
  for r in plan['new_runs']:
   if r['path'] not in verified and (Path(r['path'])/'COMPLETE.json').exists():
    try:verified[r['path']]=validate_run(r,plan)
    except json.JSONDecodeError:continue
  for node in ['A','B','C']:
   q=PAR/'workers'/node/'HEARTBEAT.json'
   snapshots[node]=read_diagnostic_json(q,snapshots.get(node))
  hb={'pid':os.getpid(),'host':socket.gethostname(),'utc':now(),'phase':'PARALLEL_TRAINING' if len(verified)<28 else 'FREEZE_ID_MODELS','n_new_training_complete':len(verified),'n_new_training_planned':28,'workers':snapshots,'legacy_dispatcher_paused_or_retired':True,'amendment_directory':str(PAR)}
  publish_status(PAR/'HEARTBEAT.json',hb);publish_status(STUDY/'HEARTBEAT.json',hb);publish_status(STUDY/'NEW_TRAINING_PROGRESS.json',{'n_complete':len(verified),'n_planned':28,'records':list(verified.values()),'parallel_amendment_sha256':args.amendment_sha,'utc':now()})
  if len(verified)==28:break
  time.sleep(20)
 # Wait until all workers have closed training jobs and their training GPU lock scopes.
 while not all((PAR/'workers'/n/'ASSIGNED_TRAINING_COMPLETE.json').exists() for n in ['A','B','C']):
  abort_check();time.sleep(10)
 validate_sources(plan);sys.path.insert(0,str(STUDY));from r2_component_factorial_preflight import audit_run
 anchors=[audit_run(r) for r in plan['anchors']]
 for r in anchors:r['checkpoint_sha256']=r['frozen_hashes']['best.pt']
 records=[validate_run(r,plan) for r in plan['new_runs']]
 for seed in plan['seeds']:assert len({r['initial_state_sha256'] for r in records if r['seed']==seed})==1,('INITIAL_STATES_DIFFER',seed)
 all_records=anchors+records;assert len(all_records)==40 and len({(tuple(r['components']),r['seed']) for r in all_records})==40
 assert not list((STUDY/'OOD_evaluations').glob('*')),'Factorial OOD started before all-ID gate'
 gate={'status':'ALL_40_ID_TRAINING_FROZEN','utc':now(),'records':all_records,'n_old':12,'n_new':28,'no_classification_performance_exclusion':True,'same_previously_examined_OOD_domains':True,'new_OOD_started_before_gate':False,'parallel_amendment_sha256':args.amendment_sha,'original_protocol_sha256':amend['original_protocol_sha256']}
 write(STUDY/'ALL_40_ID_FROZEN_GATE.json',gate,True);write(PAR/'ID_FREEZE_COMPLETE.json',{'gate_sha256':sha(STUDY/'ALL_40_ID_FROZEN_GATE.json'),'utc':now()},True)
 while True:
  for node in ['A','B','C']:
   ep=PAR/'workers'/node/'ERROR.json'
   if ep.exists():raise RuntimeError({'node':node,'worker_error':read(ep)})
  n=len(list((STUDY/'OOD_evaluations').glob('*/COMPLETE.json')));snaps={node:read_diagnostic_json(PAR/'workers'/node/'HEARTBEAT.json',snapshots.get(node)) for node in ['A','B','C']}
  hb={'pid':os.getpid(),'utc':now(),'phase':'PARALLEL_OOD_EVALUATION','n_OOD_complete':n,'n_OOD_planned':40,'workers':snaps,'amendment_directory':str(PAR)};publish_status(PAR/'HEARTBEAT.json',hb);publish_status(STUDY/'HEARTBEAT.json',hb)
  if n==40 and all((PAR/'workers'/node/'ASSIGNED_OOD_COMPLETE.json').exists() for node in ['A','B','C']):break
  time.sleep(20)
 env={**os.environ,'CUDA_VISIBLE_DEVICES':'','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
 for script,log in [(STUDY/'r2_component_factorial_analyze.py',PAR/'FACTORIAL_ANALYSIS.log'),(PAR/'r2_parallel_independent_audit.py',PAR/'INDEPENDENT_AUDIT.log')]:
  with log.open('x') as f:r=subprocess.run([sys.executable,'-u',str(script)],stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,env=env)
  assert r.returncode==0,('CPU_ANALYSIS_OR_AUDIT_FAILED',str(log),r.returncode)
 proof=read(PAR/'INDEPENDENT_RAW_METRIC_AUDIT_PASS.json');assert proof['all_pass']
 write(STUDY/'ALL_DONE.json',{'status':'TRAINING_AND_OOD_AND_FACTORIAL_ANALYSIS_COMPLETE','utc':now(),'independent_metric_audit_pass':True,'audit_sha256':sha(PAR/'INDEPENDENT_RAW_METRIC_AUDIT_PASS.json'),'parallel_amendment_sha256':args.amendment_sha,'must_audit_manuscript_consistency_before_submission':True},True)
 hb={'pid':os.getpid(),'utc':now(),'phase':'PARALLEL_STUDY_COMPLETE','amendment_directory':str(PAR)};publish_status(PAR/'HEARTBEAT.json',hb);publish_status(STUDY/'HEARTBEAT.json',hb)
if __name__=='__main__':
 try:main()
 except BaseException as exc:write(PAR/'GLOBAL_ERROR.json',{'error':repr(exc),'utc':now(),'partial_outputs_preserved':True});raise
